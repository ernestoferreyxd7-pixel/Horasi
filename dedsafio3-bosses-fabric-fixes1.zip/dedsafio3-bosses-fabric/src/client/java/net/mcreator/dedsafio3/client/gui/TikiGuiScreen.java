package net.mcreator.dedsafio3.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.mcreator.dedsafio3.network.Dedsafio3ModNetwork;
import net.mcreator.dedsafio3.world.inventory.TikiGuiMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.HashMap;

/** Pantalla "Tiki King Control Panel" (TikiGuiScreen original: 176x166, mismos textos, posiciones y botones). */
public class TikiGuiScreen extends AbstractContainerScreen<TikiGuiMenu> {
    private final static HashMap<String, Object> guistate = TikiGuiMenu.guistate;
    private final Level world;
    private final int x, y, z;
    private final Player entity;
    private static final ResourceLocation texture = ResourceLocation.fromNamespaceAndPath("dedsafio3", "textures/screens/tiki_gui.png");

    public TikiGuiScreen(TikiGuiMenu container, Inventory inventory, Component text) {
        super(container, inventory, text);
        this.world = container.world;
        this.x = container.x;
        this.y = container.y;
        this.z = container.z;
        this.entity = container.entity;
        this.imageWidth = 176;
        this.imageHeight = 166;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);
        this.renderTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
        RenderSystem.setShaderColor(1, 1, 1, 1);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
        RenderSystem.disableBlend();
    }

    @Override
    public boolean keyPressed(int key, int b, int c) {
        if (key == 256) {
            this.minecraft.player.closeContainer();
            return true;
        }
        return super.keyPressed(key, b, c);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, Component.translatable("gui.dedsafio3.tiki_gui.label_tiki_king_control_panel"), 30, 5, -12829636, false);
        guiGraphics.drawString(this.font, Component.translatable("gui.dedsafio3.tiki_gui.label_combat"), 6, 70, -12829636, false);
        guiGraphics.drawString(this.font, Component.translatable("gui.dedsafio3.tiki_gui.label_movement"), 6, 16, -12829636, false);
    }

    @Override
    public void onClose() {
        super.onClose();
    }

    @Override
    public void init() {
        super.init();
        // id 0: Walk to player
        Button walk = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_walk_to_player"), e -> send(0))
                .bounds(this.leftPos + 6, this.topPos + 25, 98, 20).build();
        guistate.put("button:button_walk_to_player", walk);
        this.addRenderableWidget(walk);
        // id 1: Cleark walk pos
        Button clear = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_cleark_walk_pos"), e -> send(1))
                .bounds(this.leftPos + 6, this.topPos + 43, 103, 20).build();
        guistate.put("button:button_cleark_walk_pos", clear);
        this.addRenderableWidget(clear);
        // Invocation / Spin / Sword: en el original su acción estaba vacía (sin efecto). Se conservan igual.
        Button invocation = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_invocation"), e -> {
        }).bounds(this.leftPos + 6, this.topPos + 79, 77, 20).build();
        guistate.put("button:button_invocation", invocation);
        this.addRenderableWidget(invocation);
        Button spin = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_spin"), e -> {
        }).bounds(this.leftPos + 6, this.topPos + 97, 46, 20).build();
        guistate.put("button:button_spin", spin);
        this.addRenderableWidget(spin);
        Button sword = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_sword"), e -> {
        }).bounds(this.leftPos + 6, this.topPos + 115, 51, 20).build();
        guistate.put("button:button_sword", sword);
        this.addRenderableWidget(sword);
        // id 5: Dash
        Button dash = Button.builder(Component.translatable("gui.dedsafio3.tiki_gui.button_dash"), e -> send(5))
                .bounds(this.leftPos + 6, this.topPos + 133, 46, 20).build();
        guistate.put("button:button_dash", dash);
        this.addRenderableWidget(dash);
    }

    private void send(int buttonId) {
        ClientPlayNetworking.send(new Dedsafio3ModNetwork.TikiGuiButtonPayload(buttonId, x, y, z));
    }
}
