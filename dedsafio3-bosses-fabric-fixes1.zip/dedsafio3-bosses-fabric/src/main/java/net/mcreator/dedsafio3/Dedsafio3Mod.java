package net.mcreator.dedsafio3;

import net.fabricmc.api.ModInitializer;
import net.mcreator.dedsafio3.init.Dedsafio3ModEntities;
import net.mcreator.dedsafio3.init.Dedsafio3ModItems;
import net.mcreator.dedsafio3.init.Dedsafio3ModMenus;
import net.mcreator.dedsafio3.init.Dedsafio3ModTabs;
import net.mcreator.dedsafio3.network.Dedsafio3ModNetwork;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Port parcial a Fabric 1.21.1: solo Hydra, RevilBoss y TikiGuardian. */
public class Dedsafio3Mod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger(Dedsafio3Mod.class);
    public static final String MODID = "dedsafio3";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Dedsafio3 bosses (Fabric port)");
        Dedsafio3ModEntities.register();
        Dedsafio3ModItems.register();
        Dedsafio3ModTabs.register();
        Dedsafio3ModMenus.register();
        Dedsafio3ModNetwork.registerCommon();
    }
}
