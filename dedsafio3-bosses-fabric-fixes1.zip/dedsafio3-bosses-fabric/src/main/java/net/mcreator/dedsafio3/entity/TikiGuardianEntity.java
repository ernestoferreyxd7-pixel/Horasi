package net.mcreator.dedsafio3.entity;

import net.mcreator.dedsafio3.network.Dedsafio3ModVariables;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Port a Fabric 1.21.1 de net.mcreator.dedsafio3.entity.TikiGuardianEntity (Forge 1.20.1, GeckoLib 4).
 * La lógica proviene del bytecode original; ver README.
 */
public class TikiGuardianEntity extends Monster implements GeoEntity {
    public static final EntityDataAccessor<Boolean> SHOOT = SynchedEntityData.defineId(TikiGuardianEntity.class, EntityDataSerializers.BOOLEAN);
    public static final EntityDataAccessor<String> ANIMATION = SynchedEntityData.defineId(TikiGuardianEntity.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<String> TEXTURE = SynchedEntityData.defineId(TikiGuardianEntity.class, EntityDataSerializers.STRING);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private boolean swinging;
    private boolean lastloop;
    private long lastSwing;
    public String animationprocedure = "empty";
    String prevAnim = "empty";
    private long dashStartTime = -1L;
    private boolean isDashing = false;
    /** Ver README: tipo de daño del dash (mapping SRG f_268566_ sin resolver). */
    private static final net.minecraft.resources.ResourceKey<net.minecraft.world.damagesource.DamageType> TIKI_DASH_DAMAGE_TYPE = DamageTypes.MOB_ATTACK;

    public TikiGuardianEntity(EntityType<TikiGuardianEntity> type, Level world) {
        super(type, world);
        this.dashStartTime = -1L;
        this.isDashing = false;
        this.xpReward = 0;
        this.setNoAi(false);
        // El original llamaba setMaxUpStep(0.6f). En 1.21.1 es el atributo STEP_HEIGHT, cuyo valor por defecto ya es 0.6.
        this.setPersistenceRequired();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SHOOT, false);
        builder.define(ANIMATION, "undefined");
        builder.define(TEXTURE, "tikiguardian");
    }

    public void setTexture(String texture) {
        this.entityData.set(TEXTURE, texture);
    }

    public String getTexture() {
        return this.entityData.get(TEXTURE);
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource ds) {
        return SoundEvents.GENERIC_HURT; // "entity.generic.hurt"
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.GENERIC_DEATH; // "entity.generic.death"
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        compound.putString("Texture", this.getTexture());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        if (compound.contains("Texture"))
            this.setTexture(compound.getString("Texture"));
    }

    /** Equivale al handler LivingTickEvent de EntityAnimationFactory del mod original (se dispara al inicio de LivingEntity#tick). */
    @Override
    public void tick() {
        String animation = this.getSyncedAnimation();
        if (!animation.equals("undefined")) {
            this.setAnimation("undefined");
            this.animationprocedure = animation;
        }
        super.tick();
    }

    @Override
    public void baseTick() {
        super.baseTick();
        this.refreshDimensions();
        // --- Walk: controlado por MapVariables.TikiWalk ---
        if (Dedsafio3ModVariables.MapVariables.get(this.level()).TikiWalk) {
            Player nearest = this.level().getNearestPlayer(this, 100.0);
            if (nearest != null && !nearest.isCreative() && !nearest.isSpectator()) {
                this.getNavigation().moveTo(nearest, 0.8);
            } else {
                this.getNavigation().stop();
            }
        } else {
            this.getNavigation().stop();
        }

        // --- Dash: controlado por MapVariables.TikiDash (dura 40 ticks) ---
        if (Dedsafio3ModVariables.MapVariables.get(this.level()).TikiDash) {
            if (this.dashStartTime == -1L) {
                this.dashStartTime = this.level().getGameTime();
            }
            Player nearest = this.level().getNearestPlayer(this, 100.0);
            if (nearest != null && !nearest.isCreative() && !nearest.isSpectator()) {
                Vec3 direction = new Vec3(nearest.getX() - this.getX(), 0, nearest.getZ() - this.getZ()).normalize();
                this.setYRot((float) Math.toDegrees(Math.atan2(direction.x, direction.z)) - 90.0f);
                this.setDeltaMovement(direction.scale(1.1));
                for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(1.5))) {
                    if (entity instanceof LivingEntity && entity != this) {
                        // TIPO DE DAÑO: el bytecode usa DamageTypes.f_268566_ (nombre SRG) y no pude resolver su
                        // nombre Mojang sin los mappings. Ver README, punto "Pendiente de verificar #1".
                        entity.hurt(new DamageSource(this.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                                .getHolderOrThrow(TIKI_DASH_DAMAGE_TYPE)), 5.0f);
                        Vec3 knockback = direction.scale(2.5).add(0, 0.5, 0);
                        entity.push(knockback.x, knockback.y, knockback.z);
                    }
                }
            }
            if (this.level().getGameTime() - this.dashStartTime >= 40L) {
                Dedsafio3ModVariables.MapVariables.get(this.level()).TikiDash = false;
                Dedsafio3ModVariables.MapVariables.get(this.level()).syncData(this.level());
                this.dashStartTime = -1L;
            }
        }
    }


    public static AttributeSupplier.Builder createAttributes() {
        AttributeSupplier.Builder builder = Mob.createMobAttributes();
        builder = builder.add(Attributes.MOVEMENT_SPEED, 0.3);
        builder = builder.add(Attributes.MAX_HEALTH, 10);
        builder = builder.add(Attributes.ARMOR, 0);
        builder = builder.add(Attributes.ATTACK_DAMAGE, 3);
        builder = builder.add(Attributes.FOLLOW_RANGE, 16);
        return builder;
    }

    private PlayState movementPredicate(AnimationState<TikiGuardianEntity> event) {
        if (this.animationprocedure.equals("empty")) {
            if ((event.isMoving() || !(event.getLimbSwingAmount() > -0.15F && event.getLimbSwingAmount() < 0.15F))) {
                return event.setAndContinue(RawAnimation.begin().thenLoop("walk"));
            }
            if (this.isDeadOrDying()) {
                return event.setAndContinue(RawAnimation.begin().thenPlay("dead"));
            }
            return event.setAndContinue(RawAnimation.begin().thenLoop("idle"));
        }
        return PlayState.STOP;
    }

    private PlayState attackingPredicate(AnimationState<TikiGuardianEntity> event) {
        double d1 = this.getX() - this.xOld;
        double d0 = this.getZ() - this.zOld;
        float velocity = (float) Math.sqrt(d1 * d1 + d0 * d0);
        if (getAttackAnim(event.getPartialTick()) > 0f && !this.swinging) {
            this.swinging = true;
            this.lastSwing = level().getGameTime();
        }
        if (this.swinging && this.lastSwing + 7L <= level().getGameTime()) {
            this.swinging = false;
        }
        if (this.swinging && event.getController().getAnimationState() == AnimationController.State.STOPPED) {
            event.getController().forceAnimationReset();
            return event.setAndContinue(RawAnimation.begin().thenPlay("attack"));
        }
        return PlayState.CONTINUE;
    }

    private PlayState procedurePredicate(AnimationState<TikiGuardianEntity> event) {
        if (!this.animationprocedure.equals("empty") && event.getController().getAnimationState() == AnimationController.State.STOPPED
                || (!this.animationprocedure.equals(prevAnim) && !this.animationprocedure.equals("empty"))) {
            if (!this.animationprocedure.equals(prevAnim))
                event.getController().forceAnimationReset();
            event.getController().setAnimation(RawAnimation.begin().thenPlay(this.animationprocedure));
            if (event.getController().getAnimationState() == AnimationController.State.STOPPED) {
                this.animationprocedure = "empty";
                event.getController().forceAnimationReset();
            }
        } else if (this.animationprocedure.equals("empty")) {
            prevAnim = "empty";
            return PlayState.STOP;
        }
        prevAnim = this.animationprocedure;
        return PlayState.CONTINUE;
    }

    @Override
    protected void tickDeath() {
        ++this.deathTime;
        if (this.deathTime == 20) {
            this.remove(TikiGuardianEntity.RemovalReason.KILLED);
            this.dropExperience(null);
        }
    }

    public String getSyncedAnimation() {
        return this.entityData.get(ANIMATION);
    }

    public void setAnimation(String animation) {
        this.entityData.set(ANIMATION, animation);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar data) {
        data.add(new AnimationController<>(this, "movement", 4, this::movementPredicate));
        data.add(new AnimationController<>(this, "attacking", 4, this::attackingPredicate));
        data.add(new AnimationController<>(this, "procedure", 4, this::procedurePredicate));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
