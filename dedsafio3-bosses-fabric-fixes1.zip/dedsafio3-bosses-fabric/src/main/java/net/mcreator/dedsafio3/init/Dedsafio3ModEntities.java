package net.mcreator.dedsafio3.init;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.mcreator.dedsafio3.Dedsafio3Mod;
import net.mcreator.dedsafio3.entity.HydraEntity;
import net.mcreator.dedsafio3.entity.RevilBossEntity;
import net.mcreator.dedsafio3.entity.TikiGuardianEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class Dedsafio3ModEntities {
    // Valores tomados de Dedsafio3ModEntities (original): MONSTER, trackingRange 64, updateInterval 3, tamaños indicados.
    public static final EntityType<TikiGuardianEntity> TIKI_GUARDIAN = Registry.register(BuiltInRegistries.ENTITY_TYPE,
            Dedsafio3Mod.id("tiki_guardian"),
            EntityType.Builder.of(TikiGuardianEntity::new, MobCategory.MONSTER)
                    .clientTrackingRange(64).updateInterval(3).sized(4.5f, 5.0f).build("tiki_guardian"));

    public static final EntityType<RevilBossEntity> REVIL_BOSS = Registry.register(BuiltInRegistries.ENTITY_TYPE,
            Dedsafio3Mod.id("revil_boss"),
            EntityType.Builder.of(RevilBossEntity::new, MobCategory.MONSTER)
                    .clientTrackingRange(64).updateInterval(3).sized(3.0f, 6.6f).build("revil_boss"));

    public static final EntityType<HydraEntity> HYDRA = Registry.register(BuiltInRegistries.ENTITY_TYPE,
            Dedsafio3Mod.id("hydra"),
            EntityType.Builder.of(HydraEntity::new, MobCategory.MONSTER)
                    .clientTrackingRange(64).updateInterval(3).sized(3.0f, 30.0f).build("hydra"));

    public static void register() {
        FabricDefaultAttributeRegistry.register(TIKI_GUARDIAN, TikiGuardianEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(REVIL_BOSS, RevilBossEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HYDRA, HydraEntity.createAttributes());
    }
}
