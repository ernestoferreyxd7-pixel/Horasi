package net.mcreator.dedsafio3.init;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.mcreator.dedsafio3.Dedsafio3Mod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;

public class Dedsafio3ModTabs {
    // El mod original agrupa sus objetos en la pestaña "pakomods" (item_group.dedsafio3.pakomods).
    public static final CreativeModeTab PAKOMODS = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
            Dedsafio3Mod.id("pakomods"),
            FabricItemGroup.builder()
                    .title(Component.translatable("item_group.dedsafio3.pakomods"))
                    .icon(() -> new ItemStack(Dedsafio3ModItems.HYDRA_SPAWN_EGG))
                    .displayItems((params, output) -> {
                        output.accept(Dedsafio3ModItems.REVIL_BOSS_SPAWN_EGG);
                        output.accept(Dedsafio3ModItems.TIKI_GUARDIAN_SPAWN_EGG);
                        output.accept(Dedsafio3ModItems.HYDRA_SPAWN_EGG);
                    })
                    .build());

    public static void register() {
        // También en la pestaña vanilla de huevos, para encontrarlos fácilmente.
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(entries -> {
            entries.accept(Dedsafio3ModItems.REVIL_BOSS_SPAWN_EGG);
            entries.accept(Dedsafio3ModItems.TIKI_GUARDIAN_SPAWN_EGG);
            entries.accept(Dedsafio3ModItems.HYDRA_SPAWN_EGG);
        });
    }
}
