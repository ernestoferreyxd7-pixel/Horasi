package net.mcreator.dedsafio3.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.mcreator.dedsafio3.Dedsafio3Mod;
import net.mcreator.dedsafio3.procedures.ShowguiProcedure;
import net.mcreator.dedsafio3.procedures.TWDisableProcedure;
import net.mcreator.dedsafio3.procedures.TikiDashProcedure;
import net.mcreator.dedsafio3.procedures.TikiWalkEnableProcedure;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public final class Dedsafio3ModNetwork {
    private Dedsafio3ModNetwork() {
    }

    /** Equivale a GMessage (tecla G): C2S. */
    public record GPressPayload(int pressType, int pressedms) implements CustomPacketPayload {
        public static final Type<GPressPayload> TYPE = new Type<>(Dedsafio3Mod.id("g_message"));
        public static final StreamCodec<RegistryFriendlyByteBuf, GPressPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.INT, GPressPayload::pressType,
                ByteBufCodecs.INT, GPressPayload::pressedms,
                GPressPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Equivale a TikiGuiButtonMessage: C2S. */
    public record TikiGuiButtonPayload(int buttonID, int x, int y, int z) implements CustomPacketPayload {
        public static final Type<TikiGuiButtonPayload> TYPE = new Type<>(Dedsafio3Mod.id("tiki_gui_button"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TikiGuiButtonPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.INT, TikiGuiButtonPayload::buttonID,
                ByteBufCodecs.INT, TikiGuiButtonPayload::x,
                ByteBufCodecs.INT, TikiGuiButtonPayload::y,
                ByteBufCodecs.INT, TikiGuiButtonPayload::z,
                TikiGuiButtonPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Sustituye a SavedDataSyncMessage (solo las dos variables de Tiki): S2C. */
    public record MapVariablesSyncPayload(boolean tikiWalk, boolean tikiDash) implements CustomPacketPayload {
        public static final Type<MapVariablesSyncPayload> TYPE = new Type<>(Dedsafio3Mod.id("map_variables_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, MapVariablesSyncPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.BOOL, MapVariablesSyncPayload::tikiWalk,
                ByteBufCodecs.BOOL, MapVariablesSyncPayload::tikiDash,
                MapVariablesSyncPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void registerCommon() {
        PayloadTypeRegistry.playC2S().register(GPressPayload.TYPE, GPressPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(TikiGuiButtonPayload.TYPE, TikiGuiButtonPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MapVariablesSyncPayload.TYPE, MapVariablesSyncPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(GPressPayload.TYPE,
                (payload, context) -> pressAction(context.player(), payload.pressType(), payload.pressedms()));
        ServerPlayNetworking.registerGlobalReceiver(TikiGuiButtonPayload.TYPE,
                (payload, context) -> handleButtonAction(context.player(), payload.buttonID(), payload.x(), payload.y(), payload.z()));

        // Equivale al sync al iniciar sesión de las variables de mundo.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            Dedsafio3ModVariables.MapVariables vars = Dedsafio3ModVariables.MapVariables.get(server.overworld());
            sender.sendPacket(new MapVariablesSyncPayload(vars.TikiWalk, vars.TikiDash));
        });
    }

    public static void sendMapVariablesToAll(MinecraftServer server, Dedsafio3ModVariables.MapVariables vars) {
        MapVariablesSyncPayload payload = new MapVariablesSyncPayload(vars.TikiWalk, vars.TikiDash);
        for (ServerPlayer player : PlayerLookup.all(server)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    /** GMessage.pressAction: la tecla G abre el panel de Tiki. */
    public static void pressAction(Player entity, int type, int pressedms) {
        Level world = entity.level();
        double x = entity.getX();
        double y = entity.getY();
        double z = entity.getZ();
        if (!world.hasChunkAt(entity.blockPosition()))
            return;
        if (type == 0) {
            ShowguiProcedure.execute(world, x, y, z, entity);
        }
    }

    /** TikiGuiButtonMessage.handleButtonAction: botones 0 (walk), 1 (clear walk) y 5 (dash). Los botones 2, 3 y 4 no hacían nada en el original. */
    public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
        Level world = entity.level();
        if (!world.hasChunkAt(new BlockPos(x, y, z)))
            return;
        if (buttonID == 0) {
            TikiWalkEnableProcedure.execute(world);
        }
        if (buttonID == 1) {
            TWDisableProcedure.execute(world);
        }
        if (buttonID == 5) {
            TikiDashProcedure.execute(world);
        }
    }
}
