package net.mcreator.dedsafio3.network;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Solo las variables de mundo que usa TikiGuardian (TikiWalk, TikiDash). El original tenía ~30 más
 * (botones, phantom, plague...) que no pertenecen a los tres jefes y no se portan.
 * Se conserva el nombre de datos "dedsafio3_mapvars" y las claves NBT originales.
 */
public class Dedsafio3ModVariables {
    public static class MapVariables extends SavedData {
        public static final String DATA_NAME = "dedsafio3_mapvars";
        public boolean TikiWalk = false;
        public boolean TikiDash = false;
        /** Copia del cliente, actualizada por el servidor mediante MapVariablesSyncPayload. */
        public static MapVariables clientSide = new MapVariables();

        public MapVariables() {
        }

        public static MapVariables load(CompoundTag tag, HolderLookup.Provider lookupProvider) {
            MapVariables data = new MapVariables();
            data.read(tag);
            return data;
        }

        public void read(CompoundTag nbt) {
            TikiWalk = nbt.getBoolean("TikiWalk");
            TikiDash = nbt.getBoolean("TikiDash");
        }

        @Override
        public CompoundTag save(CompoundTag nbt, HolderLookup.Provider lookupProvider) {
            nbt.putBoolean("TikiWalk", TikiWalk);
            nbt.putBoolean("TikiDash", TikiDash);
            return nbt;
        }

        /** En el servidor: marca como modificado y envía a todos los jugadores. En el cliente no hace nada (el servidor es la autoridad). */
        public void syncData(LevelAccessor world) {
            this.setDirty();
            if (world instanceof ServerLevel serverLevel) {
                Dedsafio3ModNetwork.sendMapVariablesToAll(serverLevel.getServer(), this);
            }
        }

        public static MapVariables get(LevelAccessor world) {
            if (world instanceof ServerLevelAccessor serverLevelAccessor) {
                return serverLevelAccessor.getLevel().getServer().getLevel(Level.OVERWORLD).getDataStorage()
                        .computeIfAbsent(new SavedData.Factory<>(MapVariables::new, MapVariables::load, null), DATA_NAME);
            }
            return clientSide;
        }
    }
}
