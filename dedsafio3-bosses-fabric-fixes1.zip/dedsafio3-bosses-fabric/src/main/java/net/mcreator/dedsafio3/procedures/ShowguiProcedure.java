package net.mcreator.dedsafio3.procedures;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.mcreator.dedsafio3.world.inventory.TikiGuiMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.LevelAccessor;

public class ShowguiProcedure {
    public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity == null)
            return;
        if (entity instanceof ServerPlayer player) {
            final BlockPos pos = BlockPos.containing(x, y, z);
            player.openMenu(new ExtendedScreenHandlerFactory<BlockPos>() {
                @Override
                public Component getDisplayName() {
                    return Component.literal("TikiGui");
                }

                @Override
                public AbstractContainerMenu createMenu(int id, Inventory inventory, Player p) {
                    return new TikiGuiMenu(id, inventory, pos);
                }

                @Override
                public BlockPos getScreenOpeningData(ServerPlayer p) {
                    return pos;
                }
            });
        }
    }
}
