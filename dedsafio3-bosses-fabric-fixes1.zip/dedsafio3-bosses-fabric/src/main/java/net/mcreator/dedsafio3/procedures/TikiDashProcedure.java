package net.mcreator.dedsafio3.procedures;

import net.mcreator.dedsafio3.network.Dedsafio3ModVariables;
import net.minecraft.world.level.LevelAccessor;

public class TikiDashProcedure {
    public static void execute(LevelAccessor world) {
        Dedsafio3ModVariables.MapVariables.get(world).TikiDash = true;
        Dedsafio3ModVariables.MapVariables.get(world).syncData(world);
    }
}
