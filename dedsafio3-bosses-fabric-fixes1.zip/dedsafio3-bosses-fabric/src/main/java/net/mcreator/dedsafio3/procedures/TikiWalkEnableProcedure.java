package net.mcreator.dedsafio3.procedures;

import net.mcreator.dedsafio3.network.Dedsafio3ModVariables;
import net.minecraft.world.level.LevelAccessor;

public class TikiWalkEnableProcedure {
    public static void execute(LevelAccessor world) {
        Dedsafio3ModVariables.MapVariables.get(world).TikiWalk = true;
        Dedsafio3ModVariables.MapVariables.get(world).syncData(world);
    }
}
